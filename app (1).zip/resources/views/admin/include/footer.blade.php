 <!-- Footer -->
@php
    $year = date('Y');
@endphp

<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; {{$general->site_name}} {{$year}}</span>
        </div>
    </div>
</footer>

 <!-- End of Footer -->