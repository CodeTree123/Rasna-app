@props(['route' => ''])

<a href="{{ $route }}" class="btn btn-sm btn-outline-primary">
    <i class="fa fa-undo"></i> @lang('Back')
</a>
