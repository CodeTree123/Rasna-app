 <!-- Footer -->
<?php
    $year = date('Y');
?>

<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; <?php echo e($general->site_name); ?> <?php echo e($year); ?></span>
        </div>
    </div>
</footer>

 <!-- End of Footer --><?php /**PATH /home1/rasnapharmabd/public_html/resources/views/admin/include/footer.blade.php ENDPATH**/ ?>