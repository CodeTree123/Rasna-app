<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-around">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-secondary text-white">
                    <h3>Add Product</h3>
                    <div class="col-md-6 d-flex">
                        <a href="<?php echo e(route('admin.account.list.product')); ?>" class="btn btn-primary m-1">Product List</a>
                    </div>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.account.add.product')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <div class="form-label">Product Name</div>
                            <input type="text" name="name" class="form-control" placeholder="Enter Product Name">
                        </div>
                        <div class="form-group">
                            <div class="form-label">Product Price</div>
                            <input type="text" name="price" class="form-control" placeholder="Enter Product Price">
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/rasnapharmabd/public_html/resources/views/admin/product/index.blade.php ENDPATH**/ ?>