

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-end">
        <div class="col-md-6">
            <h2><?php echo e($pageTitle); ?></h2>
        </div>
        <div class="col-md-6">
            <?php if($pageTitle == 'Dealer Order Details'): ?>
            <form action="<?php echo e(url('admin/report/price/report/dealer')); ?>/<?php echo e($id); ?>" method="GET">
                <?php else: ?>
                <form action="<?php echo e(url('admin/report/price/report/seller')); ?>/<?php echo e($id); ?>" method="GET">
                    <?php endif; ?>

                    <div class="row">
                        <div class="form-group col-md-3">
                            <label for="start_date">Start Date:</label>
                            <input type="date" class="form-control" id="start_date" name="start_date" value="<?php echo e(old('start_date')); ?>">
                        </div>
                        <div class="form-group col-md-3">
                            <label for="end_date">End Date:</label>
                            <input type="date" class="form-control" id="end_date" name="end_date">
                        </div>
                        <button type="submit" class="btn btn-primary p-2 m-3">Submit</button>
                    </div>
                </form>
        </div>
    </div>
    <div class="row justify-content-between">
        <?php if(isset($customDatePrice) && isset($customDateOrders)): ?>
        <div class="col-md-6">
            <div class="card mt-2">
                <div class="card-header bg-warning">
                    <h3>Custom Date Range</h3>
                </div>
                <div class="card-body bg-dark text-white">
                    <p>Total Amount: <?php echo e($customDatePrice); ?></p>
                    <p>Total Orders: <?php echo e($customDateOrders); ?> BDT.</p>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <div class="col-md-6">
            <div class="card mt-2">
                <div class="card-header bg-warning">
                    <h3>Todays Information</h3>
                </div>
                <div class="card-body bg-dark text-white">
                    <p>Total Orders: <?php echo e($currentDayOrders); ?> </p>
                    <p>Total Amount: <?php echo e($currentDayPrice); ?> BDT.</p>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card mt-2">
                <div class="card-header bg-warning">
                    <h3>Current Month Information</h3>
                </div>
                <div class="card-body bg-dark text-white">
                    <p>Total Orders: <?php echo e($currentMonthOrders); ?> </p>
                    <p>Total Amount: <?php echo e($currentMonthPrice); ?> BDT.</p><br>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card mt-2">
                <div class="card-header bg-warning">
                    <h3>Current Year Information</h3>
                </div>
                <div class="card-body bg-dark text-white">
                    <p>Total Orders: <?php echo e($currentYearOrders); ?> </p>
                    <p>Total Amount: <?php echo e($currentYearPrice); ?> BDT.</p><br>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/rasnapharmabd/public_html/resources/views/admin/report/view.blade.php ENDPATH**/ ?>