
    <div class="d-flex flex-wrap justify-content-end gap-2 align-items-center breadcrumb-plugins">
        <?php echo $__env->yieldPushContent('breadcrumb-plugins'); ?>
    </div>

<?php /**PATH /home1/rasnapharmabd/public_html/resources/views/admin/partials/breadcrumb.blade.php ENDPATH**/ ?>