<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e($pageTitle); ?></title>
    <link rel="shortcut icon" type="image/png" href="<?php echo e(getImage(getFilePath('logoIcon') .'/favicon.png')); ?>">

<?php echo $__env->make('admin.include.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldPushContent('style-lib'); ?>
<?php echo $__env->yieldPushContent('style'); ?>
<style>

</style>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-primary shadow-sm ">
            <div class="container">

                <a class="navbar-brand" href="<?php echo e(route('user.home')); ?>">
                <img class="rounded" src="<?php echo e(getImage(getFilePath('logoIcon') .'/logo.png')); ?>" width="50px" height="50px" id="my_logo_image">
                </a>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse d-flex flex-row-reverse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav me-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ms-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('user.login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link text-white" href="<?php echo e(route('user.login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('user.register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link text-white" href="<?php echo e(route('user.register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown"  class="nav-link dropdown-toggle text-white" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    Support Ticket
                                </a>
                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('ticket.open')); ?>">
                                    <?php echo app('translator')->get('Create New'); ?>
                                    </a>
                                    <a class="dropdown-item" href="<?php echo e(route('ticket.index')); ?>" >
                                    <?php echo app('translator')->get('My Ticket'); ?>
                                    </a>

                                </div>
                            </li>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown"  class="nav-link dropdown-toggle text-white" href="#" role="button"data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    Deposit
                                </a>
                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('user.deposit.index')); ?>">
                                        <?php echo e(__('Deposit Money')); ?>

                                    </a>
                                    <a class="dropdown-item" href="<?php echo e(route('user.deposit.history')); ?>" >
                                        <?php echo e(__('Deposit Log')); ?>

                                    </a>

                                </div>
                            </li>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown"  class="nav-link dropdown-toggle text-white" href="#" role="button"data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    Withdraw
                                </a>
                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('user.withdraw')); ?>">
                                        <?php echo e(__('Withdraw Money')); ?>

                                    </a>
                                    <a class="dropdown-item" href="<?php echo e(route('user.withdraw.history')); ?>" >
                                        <?php echo e(__('Withdraw
                                    Log')); ?>

                                    </a>

                                </div>
                            </li>

                            <li class="nav-item dropdown">
                                <a  class="nav-link text-white" href="<?php echo e(route('user.transactions')); ?>" role="button">
                                    Transaction
                                </a>
                            </li>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle text-white" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::user()->fullname); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('user.change.password')); ?>">
                                        <?php echo app('translator')->get('Change Password'); ?>
                                    </a>
                                    <a class="dropdown-item" href="<?php echo e(route('user.profile.setting')); ?>">
                                        <?php echo app('translator')->get('Profile Setting'); ?>
                                    </a>
                                    <a class="dropdown-item" href="<?php echo e(route('user.twofactor')); ?>">
                                        <?php echo app('translator')->get('2FA Security'); ?>
                                    </a>
                                    <a class="dropdown-item" href="<?php echo e(route('user.logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('user.logout')); ?>" method="get" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                            
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4 ">
            <?php echo $__env->make('partials.notify', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    <!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="<?php echo e(asset('assets/global/js/jquery-3.6.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/global/js/bootstrap.bundle.min.js')); ?>"></script>

<?php echo $__env->yieldPushContent('script-lib'); ?>

<?php echo $__env->yieldPushContent('script'); ?>


</body>
</html>
<?php /**PATH /home1/rasnapharmabd/public_html/resources/views/layouts/app.blade.php ENDPATH**/ ?>